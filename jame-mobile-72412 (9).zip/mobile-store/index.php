<?php
/**
 * صفحه اصلی فروشگاه - طراحی کلاسیک
 */
require_once 'config/database.php';
require_once 'includes/functions.php';

// صفحه خوش‌آمدگویی: یک‌بار در هر نشست، هنگام ورود به صفحه اصلی
if (session_status() === PHP_SESSION_NONE) session_start();
if ($_SERVER['REQUEST_METHOD'] === 'GET' && empty($_SESSION['welcomed']) && !isset($_GET['skip']) && welcome_enabled($pdo)) {
    header('Location: welcome.php');
    exit;
}

// ============================================================
// توابع کمکی نمایش (فقط در صورت نبودن تعریف می‌شوند)
// ============================================================
if (!function_exists('ms_fa_digits')) {
    function ms_fa_digits($value) {
        return strtr((string)$value, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']);
    }
}
if (!function_exists('ms_money')) {
    function ms_money($n) {
        return ms_fa_digits(number_format((float)$n));
    }
}
if (!function_exists('ms_product_card')) {
    function ms_product_card(array $p, bool $forceDiscount = false): void {
        $isAvailable = ($p['stock_status'] === 'in_stock' && $p['stock'] > 0 && $p['price'] > 0);
        $hasSale = ($p['sale_price'] && $p['sale_price'] > 0 && $p['sale_price'] < $p['price']);
        ?>
        <article class="product-card <?= !$isAvailable ? 'out-of-stock' : '' ?>">
            <?php if (!$isAvailable): ?>
                <span class="ribbon ribbon-off">ناموجود</span>
            <?php elseif ($hasSale): ?>
                <span class="ribbon ribbon-sale"><?= ms_fa_digits((int)$p['discount_percent']) ?>٪ تخفیف</span>
            <?php endif; ?>
            <a href="product.php?id=<?= (int)$p['id'] ?>" class="product-image">
                <img src="<?= htmlspecialchars($p['main_image'] ?: 'assets/no-image.png') ?>"
                     alt="<?= htmlspecialchars($p['name']) ?>" loading="lazy"
                     onerror="this.onerror=null;this.src='assets/no-image.png'">
            </a>
            <div class="product-info">
                <h3 class="product-title">
                    <a href="product.php?id=<?= (int)$p['id'] ?>"><?= htmlspecialchars(mb_substr($p['name'], 0, 70)) ?></a>
                </h3>
                <div class="product-price">
                    <?php if ($p['price'] > 0): ?>
                        <?php if ($hasSale): ?>
                            <del class="old-price"><?= ms_money($p['price']) ?></del>
                            <span class="final-price"><?= ms_money($p['sale_price']) ?> <small>تومان</small></span>
                        <?php else: ?>
                            <span class="final-price"><?= ms_money($p['price']) ?> <small>تومان</small></span>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="no-price">تماس بگیرید</span>
                    <?php endif; ?>
                </div>
                <?php if ($isAvailable): ?>
                    <button class="btn-add-to-cart" onclick="addToCart(<?= (int)$p['id'] ?>, event)">افزودن به سبد خرید</button>
                <?php else: ?>
                    <button class="btn-disabled" disabled>ناموجود</button>
                <?php endif; ?>
            </div>
        </article>
        <?php
    }
}

// ============================================================
// ۱. دسته‌بندی‌ها
// ============================================================
$categories = $pdo->query("
    SELECT c.id, c.name, c.slug, COUNT(p.id) AS product_count
    FROM categories c
    LEFT JOIN products p ON p.category_id = c.id AND p.status = 1
    GROUP BY c.id
    HAVING product_count > 0
    ORDER BY product_count DESC
    LIMIT 12
")->fetchAll();

// ============================================================
// ۲. محصولات ویژه
// ============================================================
require_once 'includes/featured.php';
featured_ensure($pdo);
// اول محصولات منتخب مدیر؛ اگر مدیر چیزی انتخاب نکرده باشد، پرامتیازترین‌ها
$featuredProducts = $pdo->query("
    SELECT * FROM products
    WHERE status = 1 AND featured = 1
    ORDER BY id DESC
    LIMIT 12
")->fetchAll();
if (!$featuredProducts) $featuredProducts = $pdo->query("
    SELECT * FROM products
    WHERE status = 1 AND stock_status = 'in_stock' AND stock > 0 AND price > 0
    ORDER BY rating DESC, review_count DESC
    LIMIT 8
")->fetchAll();

// ============================================================
// ۳. جدیدترین محصولات
// ============================================================
$newestProducts = $pdo->query("
    SELECT * FROM products WHERE status = 1 ORDER BY id DESC LIMIT 8
")->fetchAll();

// ============================================================
// ۴. تخفیف‌دارها
// ============================================================
$discountProducts = $pdo->query("
    SELECT * FROM products
    WHERE status = 1 AND stock_status = 'in_stock'
      AND sale_price IS NOT NULL AND sale_price > 0 AND sale_price < price
    ORDER BY discount_percent DESC
    LIMIT 8
")->fetchAll();

// ============================================================
// ۵. آمار
// ============================================================
$totalProducts = $pdo->query("SELECT COUNT(*) FROM products WHERE status = 1")->fetchColumn();
$totalInStock  = $pdo->query("SELECT COUNT(*) FROM products WHERE status = 1 AND stock_status = 'in_stock'")->fetchColumn();
$cartCount     = array_sum($_SESSION['cart'] ?? []);

$catIcons = ['📱','🎧','🔋','🔌','⌚','🛡️','📷','🎮','💾','🖥️','🔊','🧰'];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars(SITE_NAME) ?> | فروشگاه آنلاین موبایل</title>
<meta name="description" content="جدیدترین گوشی‌های موبایل و لوازم جانبی با گارانتی معتبر و بهترین قیمت">
<link rel="preconnect" href="https://cdn.jsdelivr.net">
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
<style>
:root{
    --navy:#1b2a41;
    --navy-deep:#111c2d;
    --navy-soft:#2a3d5c;
    --gold:#b8923a;
    --gold-light:#d9b968;
    --gold-pale:#f4ead2;
    --burgundy:#7a1f2b;
    --cream:#faf7f2;
    --paper:#ffffff;
    --ink:#22262e;
    --muted:#6b7280;
    --line:#e6dfd0;
    --green:#2f6b4f;
    --shadow:0 2px 10px rgba(27,42,65,.07);
    --shadow-hover:0 14px 30px -10px rgba(27,42,65,.28);
}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{
    font-family:'Vazirmatn',tahoma,sans-serif;
    background:var(--cream);
    color:var(--ink);
    line-height:1.7;
    -webkit-font-smoothing:antialiased;
}
a{text-decoration:none;color:inherit;transition:color .2s,background .2s,border-color .2s}
img{max-width:100%;display:block}
button{font-family:inherit;cursor:pointer;border:none;outline:none}
ul{list-style:none}
.container{max-width:1280px;margin:0 auto;padding:0 24px}

/* ============ نوار بالایی ============ */
.top-bar{
    background:var(--navy-deep);color:#cfd6e2;
    font-size:12.5px;padding:8px 0;
}
.top-bar .container{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}
.top-bar span b{color:var(--gold-light);font-weight:600}

/* ============ هدر ============ */
.site-header{
    background:var(--paper);
    border-bottom:1px solid var(--line);
    position:sticky;top:0;z-index:100;
    box-shadow:0 2px 12px rgba(27,42,65,.05);
}
.header-inner{
    display:flex;align-items:center;justify-content:space-between;
    padding:16px 0;gap:28px;
}
.logo{display:flex;align-items:center;gap:12px;white-space:nowrap}
.logo-mark{
    width:46px;height:46px;border-radius:50%;
    background:var(--navy);color:var(--gold-light);
    display:grid;place-items:center;font-size:22px;
    border:2px solid var(--gold);
    box-shadow:0 0 0 3px var(--paper),0 0 0 4px var(--gold-light);
}
.logo-text{display:flex;flex-direction:column;line-height:1.25}
.logo-text strong{font-size:21px;font-weight:800;color:var(--navy)}
.logo-text small{font-size:11px;color:var(--gold);letter-spacing:.5px;font-weight:600}

.search-box{
    flex:1;max-width:500px;display:flex;
    border:1.5px solid var(--line);border-radius:4px;
    overflow:hidden;background:var(--cream);transition:all .25s;
}
.search-box:focus-within{border-color:var(--gold);background:#fff;box-shadow:0 0 0 3px rgba(184,146,58,.15)}
.search-box input{
    flex:1;border:none;background:transparent;
    padding:11px 16px;font-family:inherit;font-size:14px;outline:none;color:var(--ink);
}
.search-box input::placeholder{color:#9a9486}
.search-box button{
    background:var(--navy);color:var(--gold-light);
    padding:0 22px;font-size:15px;transition:background .2s;
}
.search-box button:hover{background:var(--navy-soft)}

.header-actions{display:flex;align-items:center;gap:6px}
.header-actions a{
    color:var(--navy);font-size:13px;font-weight:600;
    display:flex;align-items:center;gap:6px;
    padding:9px 14px;border-radius:4px;
    border:1px solid transparent;
}
.header-actions a:hover{border-color:var(--gold);color:var(--gold)}
.header-actions .admin-btn{background:var(--gold-pale);color:#7a5c14;border-color:var(--gold-light)}
.header-actions .register-btn{background:var(--navy);color:var(--gold-light);border-color:var(--navy)}
.header-actions .register-btn:hover{background:var(--gold);color:#fff;border-color:var(--gold)}
.cart-badge{
    background:var(--burgundy);color:#fff;font-size:11px;
    min-width:20px;padding:1px 6px;border-radius:10px;
    font-weight:700;text-align:center;
}

/* ============ ناوبری دسته‌ها ============ */
.cat-nav{background:var(--navy);overflow-x:auto;scrollbar-width:none}
.cat-nav::-webkit-scrollbar{display:none}
.cat-nav-inner{display:flex;white-space:nowrap}
.cat-nav a{
    color:#d6dbe6;font-size:13.5px;font-weight:500;
    padding:13px 20px;border-bottom:3px solid transparent;
}
.cat-nav a:hover,.cat-nav a.first{color:var(--gold-light);border-bottom-color:var(--gold)}

/* ============ Hero ============ */
.hero{
    margin:32px 0;
    background:
        radial-gradient(circle at 15% 20%,rgba(217,185,104,.18),transparent 45%),
        linear-gradient(135deg,var(--navy-deep),var(--navy) 55%,var(--navy-soft));
    color:#fff;text-align:center;
    padding:64px 32px 52px;border-radius:6px;
    position:relative;
    border:1px solid var(--gold);
    box-shadow:0 20px 40px -18px rgba(17,28,45,.55);
}
.hero::before{
    content:'';position:absolute;inset:10px;
    border:1px solid rgba(217,185,104,.45);border-radius:3px;pointer-events:none;
}
.hero .ornament{color:var(--gold-light);font-size:15px;letter-spacing:10px;margin-bottom:14px;display:block}
.hero h1{font-size:36px;font-weight:800;margin-bottom:12px;line-height:1.5}
.hero h1 em{font-style:normal;color:var(--gold-light)}
.hero p{font-size:16px;color:#d3d9e5;margin-bottom:30px;font-weight:400}
.hero-cta{
    display:inline-block;background:var(--gold);color:#fff;
    padding:12px 34px;border-radius:3px;font-weight:700;font-size:14px;
    border:1px solid var(--gold-light);margin-bottom:34px;
}
.hero-cta:hover{background:var(--gold-light);color:var(--navy-deep)}
.hero-stats{display:flex;justify-content:center;gap:0;flex-wrap:wrap}
.hero-stat{padding:6px 40px;position:relative}
.hero-stat + .hero-stat::before{
    content:'';position:absolute;right:0;top:12%;height:76%;
    width:1px;background:rgba(217,185,104,.4);
}
.hero-stat .num{font-size:28px;font-weight:800;color:var(--gold-light);display:block}
.hero-stat .label{font-size:13px;color:#c3cad8;display:block}

/* ============ مزایا ============ */
.features{
    display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    background:var(--paper);border:1px solid var(--line);border-radius:6px;
    margin-bottom:12px;box-shadow:var(--shadow);
}
.feature{
    display:flex;align-items:center;gap:14px;padding:20px 22px;
}
.feature + .feature{border-right:1px solid var(--line)}
.feature .f-icon{
    width:46px;height:46px;flex-shrink:0;border-radius:50%;
    border:1.5px solid var(--gold);color:var(--gold);
    display:grid;place-items:center;font-size:20px;background:var(--gold-pale);
}
.feature h4{font-size:14px;color:var(--navy);font-weight:700}
.feature p{font-size:12px;color:var(--muted)}

/* ============ بخش‌ها ============ */
.section{margin:56px 0}
.section-header{text-align:center;margin-bottom:30px;position:relative}
.section-header h2{
    display:inline-block;font-size:24px;font-weight:800;color:var(--navy);
    position:relative;padding:0 24px;
}
.section-header .divider{
    display:flex;align-items:center;justify-content:center;gap:12px;margin-top:8px;color:var(--gold);
}
.section-header .divider::before,.section-header .divider::after{
    content:'';height:1px;width:80px;
    background:linear-gradient(90deg,transparent,var(--gold));
}
.section-header .divider::after{background:linear-gradient(270deg,transparent,var(--gold))}
.section-header .divider span{font-size:12px}
.section-more{text-align:center;margin-top:28px}
.section-more a{
    display:inline-block;padding:10px 30px;border:1.5px solid var(--navy);
    color:var(--navy);font-weight:700;font-size:13px;border-radius:3px;
}
.section-more a:hover{background:var(--navy);color:var(--gold-light)}

/* ============ دسته‌بندی ============ */
.categories-grid{
    display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:18px;
}
.category-card{
    background:var(--paper);border:1px solid var(--line);border-radius:6px;
    padding:28px 14px 22px;text-align:center;position:relative;
    transition:all .3s;box-shadow:var(--shadow);
}
.category-card::after{
    content:'';position:absolute;bottom:0;right:50%;transform:translateX(50%);
    width:0;height:3px;background:var(--gold);transition:width .3s;
}
.category-card:hover{transform:translateY(-5px);box-shadow:var(--shadow-hover);border-color:var(--gold-light)}
.category-card:hover::after{width:60%}
.category-card .icon{
    width:62px;height:62px;margin:0 auto 14px;border-radius:50%;
    display:grid;place-items:center;font-size:28px;
    background:var(--gold-pale);border:1px solid var(--gold-light);
}
.category-card .name{font-size:14px;font-weight:700;color:var(--navy);margin-bottom:2px}
.category-card .count{font-size:12px;color:var(--muted)}

/* ============ محصولات ============ */
.products-grid{
    display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:22px;
}
.product-card{
    background:var(--paper);border:1px solid var(--line);border-radius:6px;
    overflow:hidden;position:relative;display:flex;flex-direction:column;
    transition:all .3s;box-shadow:var(--shadow);
}
.product-card:hover{transform:translateY(-6px);box-shadow:var(--shadow-hover);border-color:var(--gold-light)}
.product-card.out-of-stock{opacity:.88}
.product-card.out-of-stock .product-image img{filter:grayscale(70%)}
.ribbon{
    position:absolute;top:14px;right:0;z-index:5;
    color:#fff;font-size:11.5px;font-weight:700;
    padding:4px 14px 4px 12px;
    clip-path:polygon(0 0,100% 0,100% 100%,0 100%,8px 50%);
    padding-right:18px;
}
.ribbon-sale{background:var(--burgundy)}
.ribbon-off{background:#6b7280}
.product-image{
    display:block;background:#fcfbf8;padding:22px;text-align:center;
    border-bottom:1px solid var(--line);overflow:hidden;
}
.product-image img{
    width:100%;height:190px;object-fit:contain;transition:transform .4s;
}
.product-card:hover .product-image img{transform:scale(1.06)}
.product-info{padding:16px;flex:1;display:flex;flex-direction:column}
.product-title{
    font-size:13.5px;line-height:1.8;font-weight:600;
    height:50px;overflow:hidden;margin-bottom:12px;
}
.product-title a{color:var(--navy)}
.product-title a:hover{color:var(--gold)}
.product-price{margin-top:auto;min-height:56px;display:flex;flex-direction:column;justify-content:flex-end}
.old-price{color:#9a9486;font-size:12.5px;text-decoration:line-through}
.final-price{font-size:18px;font-weight:800;color:var(--navy)}
.final-price small{font-size:11.5px;color:var(--muted);font-weight:500}
.no-price{color:var(--burgundy);font-size:13px;font-weight:700}
.btn-add-to-cart{
    width:100%;margin-top:14px;padding:11px;border-radius:3px;
    background:var(--navy);color:var(--gold-light);
    font-size:13px;font-weight:700;border:1px solid var(--navy);
    transition:all .25s;
}
.btn-add-to-cart:hover{background:var(--gold);border-color:var(--gold);color:#fff}
.btn-disabled{
    width:100%;margin-top:14px;padding:11px;border-radius:3px;
    background:#eceae4;color:#9a9486;font-size:13px;font-weight:700;cursor:not-allowed;
}

/* ============ فوتر ============ */
.site-footer{
    background:var(--navy-deep);color:#b6bfce;
    margin-top:80px;border-top:4px solid var(--gold);
}
.footer-main{padding:52px 0 28px}
.footer-grid{
    display:grid;grid-template-columns:1.4fr 1fr 1fr 1.2fr;gap:40px;
}
.footer-col h4{
    color:#fff;font-size:15px;font-weight:700;margin-bottom:18px;
    padding-bottom:10px;position:relative;
}
.footer-col h4::after{
    content:'';position:absolute;bottom:0;right:0;width:36px;height:2px;background:var(--gold);
}
.footer-col p{font-size:13px;line-height:2;color:#97a2b6}
.footer-col li{margin-bottom:10px;font-size:13px}
.footer-col a{color:#97a2b6}
.footer-col a:hover{color:var(--gold-light)}
.footer-bottom{
    border-top:1px solid #243248;text-align:center;
    padding:18px 0;font-size:12.5px;color:#7d889c;
}

/* ============ Toast ============ */
.toast{
    position:fixed;bottom:30px;left:50%;
    transform:translateX(-50%) translateY(100px);
    padding:13px 28px;border-radius:4px;font-size:14px;font-weight:600;color:#fff;
    box-shadow:0 14px 30px -8px rgba(0,0,0,.35);
    z-index:9999;opacity:0;transition:all .4s;
    border-bottom:3px solid var(--gold);
}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
.toast.success{background:var(--navy)}
.toast.error{background:var(--burgundy)}

/* ============ ریسپانسیو ============ */
@media(max-width:992px){
    .footer-grid{grid-template-columns:1fr 1fr}
    .feature + .feature{border-right:none}
}
@media(max-width:768px){
    .container{padding:0 16px}
    .top-bar .container{justify-content:center}
    .header-inner{flex-wrap:wrap;gap:12px}
    .search-box{order:3;max-width:100%;width:100%}
    .header-actions{gap:2px}
    .header-actions a{font-size:12px;padding:7px 9px}
    .hero{padding:44px 18px 36px;margin:20px 0}
    .hero h1{font-size:24px}
    .hero p{font-size:14px}
    .hero-stat{padding:6px 18px}
    .hero-stat .num{font-size:21px}
    .section{margin:40px 0}
    .section-header h2{font-size:20px}
    .products-grid{grid-template-columns:repeat(2,1fr);gap:12px}
    .product-image{padding:12px}
    .product-image img{height:130px}
    .product-info{padding:12px}
    .product-title{font-size:12.5px;height:46px}
    .final-price{font-size:15px}
    .categories-grid{grid-template-columns:repeat(2,1fr);gap:12px}
    .footer-grid{grid-template-columns:1fr;gap:28px}
}
@media(max-width:400px){
    .products-grid{grid-template-columns:1fr}
}
</style>
</head>
<body>

<!-- ============ نوار بالایی ============ -->
<div class="top-bar">
<div class="container">
    <span>🚚 ارسال سریع به سراسر کشور &nbsp;|&nbsp; <b>گارانتی اصالت و سلامت کالا</b></span>
    <span>📞 پشتیبانی: <span dir="ltr"><?= site_fa(SITE_PHONE) ?></span></span>
</div>
</div>

<!-- ============ هدر ============ -->
<header class="site-header">
<div class="container">
<div class="header-inner">
<a href="index.php" class="logo">
    <?= site_logo_mark() ?>
    <span class="logo-text"><strong><?= htmlspecialchars(SITE_NAME) ?></strong><small>72412</small></span>
</a>

<form class="search-box" action="search.php" method="GET">
    <input type="text" name="q" placeholder="جستجوی محصول، برند یا مدل...">
    <button type="submit" aria-label="جستجو">🔍</button>
</form>

<div class="header-actions">
    <a href="cart.php">🛒 سبد خرید<?php if ($cartCount > 0): ?><span class="cart-badge"><?= ms_fa_digits($cartCount) ?></span><?php endif; ?></a>
    <a href="contact.php">📞 تماس</a>
    <?php if (isLoggedIn()): ?>
        <?php if (isAdmin()): ?>
            <a href="admin/index.php" class="admin-btn">🔧 پنل ادمین</a>
        <?php else: ?>
            <a href="account.php">👤 حساب من</a>
        <?php endif; ?>
        <a href="logout.php">🚪 خروج</a>
    <?php else: ?>
        <a href="login.php">🔐 ورود</a>
        <a href="register.php" class="register-btn">ثبت‌نام</a>
    <?php endif; ?>
</div>
</div>
</div>

<nav class="cat-nav">
<div class="container">
<div class="cat-nav-inner">
    <a href="archive.php" class="first">همه محصولات</a>
    <?php foreach ($categories as $c): ?>
        <a href="archive.php?cat=<?= (int)$c['id'] ?>"><?= htmlspecialchars($c['name']) ?></a>
    <?php endforeach; ?>
</div>
</div>
</nav>
</header>

<div class="container">

<!-- ============ Hero ============ -->
<section class="hero">
    <span class="ornament">✦ ✦ ✦</span>
    <h1>به <em><?= htmlspecialchars(SITE_NAME) ?></em> خوش آمدید</h1>
    <p>جدیدترین گوشی‌ها و لوازم جانبی با بهترین قیمت و گارانتی معتبر</p>
    <a href="archive.php" class="hero-cta">مشاهده محصولات</a>
    <div class="hero-stats">
        <div class="hero-stat"><span class="num"><?= ms_fa_digits(number_format($totalProducts)) ?></span><span class="label">محصول متنوع</span></div>
        <div class="hero-stat"><span class="num"><?= ms_fa_digits(number_format($totalInStock)) ?></span><span class="label">آماده ارسال</span></div>
        <div class="hero-stat"><span class="num">۲۴/۷</span><span class="label">پشتیبانی</span></div>
    </div>
</section>

<!-- ============ مزایا ============ -->
<section class="features">
    <div class="feature"><div class="f-icon">🛡️</div><div><h4>گارانتی معتبر</h4><p>اصالت و سلامت فیزیکی کالا</p></div></div>
    <div class="feature"><div class="f-icon">🚚</div><div><h4>ارسال سریع</h4><p>به سراسر کشور</p></div></div>
    <div class="feature"><div class="f-icon">💳</div><div><h4>پرداخت امن</h4><p>درگاه بانکی معتبر</p></div></div>
    <div class="feature"><div class="f-icon">🎧</div><div><h4>پشتیبانی ۲۴/۷</h4><p>همیشه در کنار شما</p></div></div>
</section>

<!-- ============ دسته‌بندی‌ها ============ -->
<?php if (!empty($categories)): ?>
<section class="section">
    <div class="section-header">
        <h2>دسته‌بندی‌ها</h2>
        <div class="divider"><span>◆</span></div>
    </div>
    <div class="categories-grid">
    <?php foreach ($categories as $i => $c): ?>
        <a href="archive.php?cat=<?= (int)$c['id'] ?>" class="category-card">
            <div class="icon"><?= $catIcons[$i % count($catIcons)] ?></div>
            <div class="name"><?= htmlspecialchars($c['name']) ?></div>
            <div class="count"><?= ms_fa_digits(number_format($c['product_count'])) ?> محصول</div>
        </a>
    <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- ============ پیشنهاد ویژه ============ -->
<?php if (!empty($featuredProducts)): ?>
<section class="section">
    <div class="section-header">
        <h2>پیشنهاد ویژه</h2>
        <div class="divider"><span>◆</span></div>
    </div>
    <div class="products-grid">
        <?php foreach ($featuredProducts as $p) ms_product_card($p); ?>
    </div>
    <div class="section-more"><a href="archive.php">مشاهده همه محصولات</a></div>
</section>
<?php endif; ?>

<!-- ============ تخفیف‌ها ============ -->
<?php if (!empty($discountProducts)): ?>
<section class="section">
    <div class="section-header">
        <h2>تخفیف‌های ویژه</h2>
        <div class="divider"><span>◆</span></div>
    </div>
    <div class="products-grid">
        <?php foreach ($discountProducts as $p) ms_product_card($p, true); ?>
    </div>
    <div class="section-more"><a href="archive.php">مشاهده همه تخفیف‌ها</a></div>
</section>
<?php endif; ?>

<!-- ============ جدیدترین‌ها ============ -->
<?php if (!empty($newestProducts)): ?>
<section class="section">
    <div class="section-header">
        <h2>جدیدترین محصولات</h2>
        <div class="divider"><span>◆</span></div>
    </div>
    <div class="products-grid">
        <?php foreach ($newestProducts as $p) ms_product_card($p); ?>
    </div>
    <div class="section-more"><a href="archive.php">مشاهده همه محصولات</a></div>
</section>
<?php endif; ?>

</div>

<?php require __DIR__ . '/includes/site_footer.php'; ?>

<script>
function addToCart(productId, event) {
    if (event) event.preventDefault();
    fetch('add_to_cart.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id=' + productId
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            if (data.cart_count > 0) {
                const faCount = String(data.cart_count).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
                const badge = document.querySelector('.cart-badge');
                if (badge) {
                    badge.textContent = faCount;
                } else {
                    const cartLink = document.querySelector('.header-actions a[href="cart.php"]');
                    if (cartLink) {
                        const span = document.createElement('span');
                        span.className = 'cart-badge';
                        span.textContent = faCount;
                        cartLink.appendChild(span);
                    }
                }
            }
            showToast('✅ ' + data.message, false);
        } else {
            showToast('❌ ' + data.message, true);
        }
    })
    .catch(() => showToast('خطا در ارتباط با سرور', true));
}

function showToast(message, isError) {
    if (isError === undefined) isError = false;
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'toast ' + (isError ? 'error' : 'success');
    toast.textContent = message;
    document.body.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add('show'));

    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 400);
    }, 2500);
}
</script>

</body>
</html>